package com.github.libretube.ui.dialogs

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.text.format.Formatter
import android.util.Log
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import androidx.lifecycle.lifecycleScope
import com.github.libretube.R
import com.github.libretube.api.MediaServiceRepository
import com.github.libretube.api.obj.PipedStream
import com.github.libretube.api.obj.Streams
import com.github.libretube.api.obj.Subtitle
import com.github.libretube.constants.IntentData
import com.github.libretube.databinding.DialogDownloadBinding
import com.github.libretube.db.DatabaseHolder
import com.github.libretube.extensions.TAG
import com.github.libretube.extensions.getWhileDigit
import com.github.libretube.extensions.toastFromMainDispatcher
import com.github.libretube.helpers.DownloadHelper
import com.github.libretube.helpers.PlayerHelper
import com.github.libretube.helpers.PreferenceHelper
import com.github.libretube.parcelable.DownloadData
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DownloadDialog : DialogFragment() {
    private lateinit var videoId: String
    private var onDownloadConfirm = {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        videoId = arguments?.getString(IntentData.videoId)!!
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val binding = DialogDownloadBinding.inflate(layoutInflater)

        fetchAvailableSources(binding)
        showVideoAlreadyDownloadedWarning(binding)

        return MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.download)
            .setView(binding.root)
            .setPositiveButton(R.string.download, null)
            .setNegativeButton(R.string.cancel, null)
            .show()
            .apply {
                getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                    onDownloadConfirm.invoke()
                }
            }
    }

    private fun showVideoAlreadyDownloadedWarning(binding: DialogDownloadBinding) {
        lifecycleScope.launch {
            val alreadyDownloaded = withContext(Dispatchers.IO) {
                DatabaseHolder.Database.downloadDao().getDownloadById(videoId)
            } != null

            binding.alreadyDownloadedCard.isVisible = alreadyDownloaded
        }
    }

    private fun fetchAvailableSources(binding: DialogDownloadBinding) {
        lifecycleScope.launch {
            val response = try {
                withContext(Dispatchers.IO) {
                    MediaServiceRepository.instance.getStreams(videoId)
                }
            }  catch (e: Exception) {
                Log.e(TAG(), e.stackTraceToString())
                context?.toastFromMainDispatcher(e.localizedMessage.orEmpty())
                return@launch
            }
            initDownloadOptions(binding, response)
        }
    }

    private fun initDownloadOptions(binding: DialogDownloadBinding, streams: Streams) {
        binding.videoTitle.text = streams.title

        val videoStreams = streams.videoStreams.filter {
            !it.url.isNullOrEmpty()
        }.filter { !it.format.orEmpty().contains("HLS") }.sortedByDescending {
            it.quality.getWhileDigit()
        }

        val audioStreams = streams.audioStreams.filter {
            !it.url.isNullOrEmpty()
        }
            .sortedBy {
                // prioritize main audio track types (lower role flag) over secondary/subbed ones
                PlayerHelper.getFullAudioRoleFlags(0, it.audioTrackType.orEmpty())
            }
            .sortedByDescending {
                it.quality.getWhileDigit()
            }

        val subtitles = streams.subtitles
            .filter { !it.url.isNullOrEmpty() && !it.name.isNullOrEmpty() }
            .sortedBy { it.name }

        if (subtitles.isEmpty()) binding.subtitleSpinner.isGone = true

        binding.videoSpinner.items = videoStreams.map {
            val fileSize = Formatter.formatShortFileSize(context, it.contentLength)
            "${it.quality} ${it.codec} ($fileSize)"
        }.toMutableList().also {
            it.add(0, getString(R.string.no_video))
        }

        binding.audioSpinner.items = audioStreams.map {
            val fileSize = it.contentLength
                .takeIf { l -> l > 0 }
                ?.let { cl -> Formatter.formatShortFileSize(context, cl) }
            val infoStr = listOfNotNull(it.audioTrackLocale, fileSize)
                .joinToString(", ")
            "${it.quality} ${it.format} ($infoStr)"
        }.toMutableList().also {
            it.add(0, getString(R.string.no_audio))
        }

        binding.subtitleSpinner.items = subtitles.map { it.name.orEmpty() }.toMutableList().also {
            it.add(0, getString(R.string.no_subtitle))
        }

        val profiles = listOf(
            DownloadProfile("Mejor calidad", maxVideoQuality = Int.MAX_VALUE, audioOnly = false),
            DownloadProfile("Equilibrada · hasta 720p", maxVideoQuality = 720, audioOnly = false),
            DownloadProfile("Liviana · hasta 480p", maxVideoQuality = 480, audioOnly = false),
            DownloadProfile("Solo audio", maxVideoQuality = 0, audioOnly = true)
        )
        binding.downloadProfileSpinner.items = profiles.map { it.label }
        binding.downloadProfileSpinner.selectedItemPosition = 1
        binding.videoSpinner.isGone = true
        binding.audioSpinner.isGone = true
        updateProfileSummary(binding, profiles, videoStreams, audioStreams)
        binding.downloadProfileSpinner.setOnSelectionChangeListener {
            updateProfileSummary(binding, profiles, videoStreams, audioStreams)
        }

        restorePreviousSelections(binding, videoStreams, audioStreams, subtitles)

        onDownloadConfirm = onDownloadConfirm@{
            val profile = profiles.getOrNull(binding.downloadProfileSpinner.selectedItemPosition)
                ?: profiles[1]
            val (videoStream, audioStream) = selectProfileStreams(profile, videoStreams, audioStreams)
            val subtitlePosition = binding.subtitleSpinner.selectedItemPosition - 1
            val subtitle = subtitles.getOrNull(subtitlePosition)

            if (videoStream == null && audioStream == null && subtitle == null) {
                Toast.makeText(context, R.string.nothing_selected, Toast.LENGTH_SHORT).show()
                return@onDownloadConfirm
            }

            saveSelections(videoStream, audioStream, subtitle)

            val downloadData = DownloadData(
                videoId = videoId,
                videoFormat = videoStream?.format,
                videoQuality = videoStream?.quality,
                audioFormat = audioStream?.format,
                audioQuality = audioStream?.quality,
                audioLanguage = audioStream?.audioTrackLocale,
                subtitleCode = subtitle?.code
            )
            val appContext = requireContext()
            DownloadHelper.startDownloadService(appContext, downloadData)
            val storageRoot = DownloadHelper.getDownloadDir(appContext, "").toAbsolutePath().toString()
            Toast.makeText(
                appContext,
                "Descarga iniciada (${profile.label}). Archivos de video/audio en: $storageRoot. El avance está en Biblioteca > Descargas.",
                Toast.LENGTH_LONG
            ).show()

            dismiss()
        }
    }

    private data class DownloadProfile(
        val label: String,
        val maxVideoQuality: Int,
        val audioOnly: Boolean
    )

    private fun selectProfileStreams(
        profile: DownloadProfile,
        videoStreams: List<PipedStream>,
        audioStreams: List<PipedStream>
    ): Pair<PipedStream?, PipedStream?> {
        val audio = audioStreams
            .sortedWith(
                compareBy<PipedStream> { stream ->
                    val codec = stream.codec.orEmpty().lowercase()
                    when {
                        codec.contains("mp4a") || codec.contains("aac") -> 0
                        codec.contains("opus") -> 1
                        else -> 2
                    }
                }.thenByDescending { it.bitrate ?: it.quality.getWhileDigit() ?: 0 }
            ).firstOrNull()
        if (profile.audioOnly) return null to audio

        val compatibleVideos = videoStreams.filter { stream ->
            stream.videoOnly == true && stream.url?.isNotBlank() == true
        }
        val limit = profile.maxVideoQuality
        val allowed = if (limit == Int.MAX_VALUE) compatibleVideos else {
            compatibleVideos.filter { (it.height ?: it.quality.getWhileDigit() ?: Int.MAX_VALUE) <= limit }
        }
        val selectedVideo = (allowed.ifEmpty { compatibleVideos })
            .maxByOrNull { it.height ?: it.quality.getWhileDigit() ?: 0 }
        return selectedVideo to audio
    }

    private fun updateProfileSummary(
        binding: DialogDownloadBinding,
        profiles: List<DownloadProfile>,
        videoStreams: List<PipedStream>,
        audioStreams: List<PipedStream>
    ) {
        val profile = profiles.getOrNull(binding.downloadProfileSpinner.selectedItemPosition) ?: return
        val (video, audio) = selectProfileStreams(profile, videoStreams, audioStreams)
        val details = buildList {
            if (video != null) add("Video ${video.quality.orEmpty()} ${video.codec.orEmpty()}")
            if (audio != null) add("Audio ${audio.codec.orEmpty()}")
        }
        val estimatedSize = listOfNotNull(video, audio).sumOf { it.contentLength.coerceAtLeast(0L) }
        val sizeText = if (estimatedSize > 0) Formatter.formatShortFileSize(context, estimatedSize) else "tamaño variable"
        binding.downloadProfileSummary.text = if (details.isEmpty()) {
            "No hay pistas compatibles disponibles para este perfil."
        } else {
            details.joinToString(" + ") + " · aprox. $sizeText"
        }
    }

    /**
     * Save the download selection to the preferences
     */
    private fun saveSelections(
        videoStream: PipedStream?,
        audioStream: PipedStream?,
        subtitle: Subtitle?
    ) {
        PreferenceHelper.putString(SUBTITLE_LANGUAGE, subtitle?.code.orEmpty())
        PreferenceHelper.putString(VIDEO_DOWNLOAD_FORMAT, videoStream?.format.orEmpty())
        PreferenceHelper.putString(VIDEO_DOWNLOAD_QUALITY, videoStream?.quality.orEmpty())
        PreferenceHelper.putString(AUDIO_DOWNLOAD_FORMAT, audioStream?.format.orEmpty())
        PreferenceHelper.putString(AUDIO_DOWNLOAD_QUALITY, audioStream?.quality.orEmpty())
    }

    private fun getSel(key: String) = PreferenceHelper.getString(key, "")

    /**
     * Restore the download selections from a previous session
     */
    private fun restorePreviousSelections(
        binding: DialogDownloadBinding,
        videoStreams: List<PipedStream>,
        audioStreams: List<PipedStream>,
        subtitles: List<Subtitle>
    ) {
        getStreamSelection(
            videoStreams,
            getSel(VIDEO_DOWNLOAD_QUALITY),
            getSel(VIDEO_DOWNLOAD_FORMAT)
        )?.let {
            binding.videoSpinner.selectedItemPosition = it + 1
        }
        getStreamSelection(
            audioStreams,
            getSel(AUDIO_DOWNLOAD_QUALITY),
            getSel(AUDIO_DOWNLOAD_FORMAT)
        )?.let {
            binding.audioSpinner.selectedItemPosition = it + 1
        }

        subtitles.indexOfFirst { it.code == getSel(SUBTITLE_LANGUAGE) }.takeIf { it != -1 }?.let {
            binding.subtitleSpinner.selectedItemPosition = it + 1
        }
    }

    private fun getStreamSelection(
        streams: List<PipedStream>,
        quality: String,
        format: String
    ): Int? {
        if (quality.isBlank()) return null

        streams.forEachIndexed { index, pipedStream ->
            if (quality == pipedStream.quality && format == pipedStream.format) return index
        }

        streams.forEachIndexed { index, pipedStream ->
            if (quality == pipedStream.quality) return index
        }

        val qualityInt = quality.getWhileDigit() ?: return null

        streams.forEachIndexed { index, pipedStream ->
            if ((pipedStream.quality.getWhileDigit() ?: Int.MAX_VALUE) < qualityInt) return index
        }

        return null
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)

        setFragmentResult(DOWNLOAD_DIALOG_DISMISSED_KEY, bundleOf())
    }

    companion object {
        private const val VIDEO_DOWNLOAD_QUALITY = "video_download_quality"
        private const val VIDEO_DOWNLOAD_FORMAT = "video_download_format"
        private const val AUDIO_DOWNLOAD_QUALITY = "audio_download_quality"
        private const val AUDIO_DOWNLOAD_FORMAT = "audio_download_format"
        private const val SUBTITLE_LANGUAGE = "subtitle_download_language"

        const val DOWNLOAD_DIALOG_DISMISSED_KEY = "download_dialog_dismissed_key"
    }
}
