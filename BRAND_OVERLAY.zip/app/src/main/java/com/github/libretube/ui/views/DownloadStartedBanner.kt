package com.github.libretube.ui.views

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.github.libretube.R
import com.github.libretube.constants.IntentData
import com.github.libretube.ui.activities.MainActivity

/** Brief, animated confirmation of a started download with a direct route to the Downloads screen. */
object DownloadStartedBanner {
    private const val VIEW_TAG = "la_clave_download_started_banner"
    private const val DISMISS_DELAY_MS = 8_000L
    private val handler = Handler(Looper.getMainLooper())
    private var dismissRunnable: Runnable? = null
    private var iconAnimator: ObjectAnimator? = null

    fun show(activity: Activity) {
        val root = activity.findViewById<FrameLayout>(android.R.id.content) ?: return
        (root.findViewWithTag<View>(VIEW_TAG))?.let { previous ->
            previous.animate().cancel()
            root.removeView(previous)
        }
        dismissRunnable?.let(handler::removeCallbacks)
        dismissRunnable = null
        iconAnimator?.cancel()
        iconAnimator = null

        val banner = activity.layoutInflater.inflate(R.layout.view_download_started_banner, root, false)
        banner.tag = VIEW_TAG
        val icon = banner.findViewById<View>(R.id.download_started_icon)
        banner.findViewById<View>(R.id.download_started_action).setOnClickListener {
            if (activity is MainActivity) {
                activity.openDownloadsFromDownloadBanner()
            } else {
                activity.startActivity(
                    Intent(activity, MainActivity::class.java)
                        .putExtra(IntentData.OPEN_DOWNLOADS, true)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            }
            dismiss(activity, root, banner)
        }

        val params = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            val density = activity.resources.displayMetrics.density
            val statusBarInset = ViewCompat.getRootWindowInsets(root)
                ?.getInsets(WindowInsetsCompat.Type.statusBars())?.top ?: (24 * density).toInt()
            topMargin = statusBarInset + (8 * density).toInt()
        }
        banner.alpha = 0f
        banner.translationY = -24f * activity.resources.displayMetrics.density
        root.addView(banner, params)
        banner.announceForAccessibility(activity.getString(R.string.download_started_title))
        banner.animate().alpha(1f).translationY(0f).setDuration(220L).start()

        iconAnimator = ObjectAnimator.ofFloat(
            icon,
            View.TRANSLATION_Y,
            0f,
            5f * activity.resources.displayMetrics.density,
            0f
        ).apply {
            duration = 760L
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        dismissRunnable = Runnable { dismiss(activity, root, banner) }
        handler.postDelayed(dismissRunnable!!, DISMISS_DELAY_MS)
    }

    private fun dismiss(activity: Activity, root: FrameLayout, banner: View) {
        dismissRunnable?.let(handler::removeCallbacks)
        dismissRunnable = null
        iconAnimator?.cancel()
        iconAnimator = null
        banner.animate().alpha(0f).translationY(-16f * activity.resources.displayMetrics.density)
            .setDuration(180L)
            .withEndAction { if (banner.parent === root) root.removeView(banner) }
            .start()
    }
}
