package com.github.libretube.ui.activities

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.lifecycle.lifecycleScope
import com.github.libretube.R
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class LiveTvActivity : MediaCatalogActivity() {
    private data class Channel(val name: String, val group: String, val url: String, val logo: String)
    private data class Country(val label: String, val code: String)
    private var allChannels: List<Channel> = emptyList()
    private var loadJob: Job? = null
    private val countries = listOf(
        Country("Argentina", "ar"), Country("Bolivia", "bo"), Country("Brasil", "br"),
        Country("Chile", "cl"), Country("Colombia", "co"), Country("Costa Rica", "cr"),
        Country("Cuba", "cu"), Country("Ecuador", "ec"), Country("El Salvador", "sv"),
        Country("Guatemala", "gt"), Country("Honduras", "hn"), Country("México", "mx"),
        Country("Nicaragua", "ni"), Country("Panamá", "pa"), Country("Paraguay", "py"),
        Country("Perú", "pe"), Country("Puerto Rico", "pr"), Country("República Dominicana", "do"),
        Country("Uruguay", "uy"), Country("Venezuela", "ve")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupCatalog(R.layout.activity_live_tv, R.string.live_tv_title)
        val spinner = findViewById<Spinner>(R.id.catalog_country)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, countries.map { it.label })
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                loadCountry(countries[position])
            }
        }
        findViewById<MaterialButton>(R.id.catalog_search).setOnClickListener { filterChannels() }
        findViewById<EditText>(R.id.catalog_filter).setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) { filterChannels(); true } else false
        }
    }

    private fun loadCountry(country: Country) {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            updateStatus(getString(R.string.live_tv_loading, country.label))
            try {
                val channels = withContext(Dispatchers.IO) {
                    val connection = URL("https://iptv-org.github.io/iptv/countries/${country.code}.m3u").openConnection() as HttpURLConnection
                    connection.connectTimeout = 15000
                    connection.readTimeout = 25000
                    connection.setRequestProperty("User-Agent", "LaClaveTube/1.0")
                    try { connection.inputStream.bufferedReader().use { parsePlaylist(it.readText()) } }
                    finally { connection.disconnect() }
                }
                allChannels = channels
                if (channels.isEmpty()) {
                    updateStatus(getString(R.string.live_tv_empty_country, country.label))
                } else {
                    updateStatus(getString(R.string.live_tv_loaded, country.label, channels.size))
                    filterChannels()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                updateStatus(getString(R.string.catalog_error, e.localizedMessage ?: e.javaClass.simpleName))
            }
        }
    }

    private fun parsePlaylist(m3u: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var title = ""
        var group = ""
        var logo = ""
        for (line in m3u.lineSequence()) {
            val value = line.trim()
            if (value.startsWith("#EXTINF", ignoreCase = true)) {
                val comma = value.lastIndexOf(',')
                title = if (comma >= 0) value.substring(comma + 1).trim() else value.substringAfter("tvg-name=\"").substringBefore('"')
                group = Regex("group-title=\"([^\"]*)\"").find(value)?.groupValues?.getOrNull(1).orEmpty()
                logo = Regex("tvg-logo=\"([^\"]*)\"").find(value)?.groupValues?.getOrNull(1).orEmpty()
            } else if (value.startsWith("http://") || value.startsWith("https://")) {
                if (title.isNotBlank()) result += Channel(title, group, value, logo)
                title = ""; group = ""; logo = ""
            }
        }
        return result.distinctBy { it.url }
    }

    private fun filterChannels() {
        val query = findViewById<EditText>(R.id.catalog_filter).text.toString().trim()
        val filtered = allChannels.filter { query.isBlank() || it.name.contains(query, true) || it.group.contains(query, true) }
            .take(300)
        updateStatus(
            if (filtered.isEmpty()) getString(R.string.live_tv_no_match)
            else getString(R.string.live_tv_filtered_results, filtered.size, findViewById<Spinner>(R.id.catalog_country).selectedItem.toString())
        )
        showRows(R.id.catalog_results, filtered.map { it.name to it.group }) { index ->
            val channel = filtered[index]
            updateStatus(getString(R.string.live_tv_playing, channel.name))
            val mime = if (channel.url.contains(".m3u8", true)) androidx.media3.common.MimeTypes.APPLICATION_M3U8 else null
            playUrl(channel.url, channel.name, mime)
        }
    }
}
