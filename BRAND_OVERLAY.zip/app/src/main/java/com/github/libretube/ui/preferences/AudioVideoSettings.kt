package com.github.libretube.ui.preferences

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.preference.Preference
import androidx.preference.SwitchPreferenceCompat
import com.github.libretube.R
import com.github.libretube.constants.PreferenceKeys
import com.github.libretube.helpers.PreferenceHelper
import com.github.libretube.ui.base.BasePreferenceFragment

class AudioVideoSettings : BasePreferenceFragment() {
    private val downloadFolderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            val saveToPhone = findPreference<SwitchPreferenceCompat>(
                PreferenceKeys.SAVE_DOWNLOADS_TO_PHONE_FOLDER
            )
            if (uri == null) {
                if (PreferenceHelper.getString(PreferenceKeys.DOWNLOADS_PHONE_FOLDER_URI, "").isBlank()) {
                    saveToPhone?.isChecked = false
                }
                return@registerForActivityResult
            }

            val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching {
                requireContext().contentResolver.takePersistableUriPermission(uri, takeFlags)
            }.onFailure {
                saveToPhone?.isChecked = false
                return@registerForActivityResult
            }

            PreferenceHelper.putString(PreferenceKeys.DOWNLOADS_PHONE_FOLDER_URI, uri.toString())
            PreferenceHelper.putBoolean(PreferenceKeys.SAVE_DOWNLOADS_TO_PHONE_FOLDER, true)
            saveToPhone?.isChecked = true
            updateDownloadFolderSummary(uri)
        }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.audio_video_settings, rootKey)

        val saveToPhone = findPreference<SwitchPreferenceCompat>(
            PreferenceKeys.SAVE_DOWNLOADS_TO_PHONE_FOLDER
        )
        val chooseFolder = findPreference<Preference>(PreferenceKeys.DOWNLOADS_PHONE_FOLDER_URI)
        val savedUri = PreferenceHelper.getString(PreferenceKeys.DOWNLOADS_PHONE_FOLDER_URI, "")
        if (savedUri.isNotBlank()) updateDownloadFolderSummary(Uri.parse(savedUri))

        saveToPhone?.setOnPreferenceChangeListener { _, newValue ->
            val enabled = newValue as? Boolean ?: false
            val selected = PreferenceHelper.getString(PreferenceKeys.DOWNLOADS_PHONE_FOLDER_URI, "")
            if (enabled && selected.isBlank()) {
                downloadFolderPicker.launch(null)
                false
            } else {
                true
            }
        }

        chooseFolder?.setOnPreferenceClickListener {
            val currentUri = PreferenceHelper.getString(PreferenceKeys.DOWNLOADS_PHONE_FOLDER_URI, "")
            downloadFolderPicker.launch(currentUri.takeIf { it.isNotBlank() }?.let(Uri::parse))
            true
        }
    }

    private fun updateDownloadFolderSummary(uri: Uri) {
        val folderName = runCatching {
            DocumentFile.fromTreeUri(requireContext(), uri)?.name
        }.getOrNull().orEmpty()
        findPreference<Preference>(PreferenceKeys.DOWNLOADS_PHONE_FOLDER_URI)?.summary =
            if (folderName.isBlank()) {
                getString(R.string.choose_downloads_phone_folder_summary)
            } else {
                getString(R.string.downloads_phone_folder_selected, folderName)
            }
    }
}
