package com.github.libretube.ui.views

import android.animation.ObjectAnimator
import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ProgressBar
import androidx.core.view.doOnPreDraw
import androidx.core.view.WindowCompat
import com.github.libretube.R

/** Branded startup cover. It remains visible until the caller reports that its first screen is ready. */
class StartupSplashOverlay(
    private val activity: Activity,
    private val root: ViewGroup
) {
    private val view = activity.layoutInflater.inflate(R.layout.view_startup_splash, root, false)
    private val progress = view.findViewById<ProgressBar>(R.id.startup_progress)
    private val insetsController = WindowCompat.getInsetsController(activity.window, root)
    private val previousLightStatusBars = insetsController.isAppearanceLightStatusBars
    private val previousLightNavigationBars = insetsController.isAppearanceLightNavigationBars
    private var finished = false

    init {
        insetsController.isAppearanceLightStatusBars = false
        insetsController.isAppearanceLightNavigationBars = false
        val overlayLayoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        root.addView(view, overlayLayoutParams)
    }

    fun setProgress(value: Int) {
        if (finished || !view.isAttachedToWindow) return
        progress.progress = value.coerceIn(progress.progress, 95)
    }

    fun finishAfterFirstFrame() {
        root.doOnPreDraw { finish(); true }
    }

    fun finish() {
        if (finished) return
        finished = true
        ObjectAnimator.ofInt(progress, "progress", progress.progress, 100).apply {
            duration = 260L
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        Handler(Looper.getMainLooper()).postDelayed({
            if (!activity.isFinishing && view.isAttachedToWindow) {
                view.animate()
                    .alpha(0f)
                    .setDuration(220L)
                    .withEndAction {
                        (view.parent as? ViewGroup)?.removeView(view)
                        insetsController.isAppearanceLightStatusBars = previousLightStatusBars
                        insetsController.isAppearanceLightNavigationBars = previousLightNavigationBars
                    }
                    .start()
            }
        }, 280L)
    }
}
