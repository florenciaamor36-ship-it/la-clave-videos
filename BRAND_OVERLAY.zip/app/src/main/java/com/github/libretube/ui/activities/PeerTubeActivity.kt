package com.github.libretube.ui.activities

import android.net.Uri
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.lifecycle.lifecycleScope
import com.github.libretube.R
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class PeerTubeActivity : MediaCatalogActivity() {
    private data class Instance(val label: String, val base: String)
    private data class Video(val title: String, val host: String, val uuid: String, val channel: String, val description: String)
    private val instances = listOf(
        Instance("PeerTube.tv", "https://peertube.tv"),
        Instance("Tchncs", "https://tube.tchncs.de"),
        Instance("Framatube", "https://framatube.org")
    )
    private var videos: List<Video> = emptyList()
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupCatalog(R.layout.activity_peertube, R.string.peertube_title)
        val spinner = findViewById<Spinner>(R.id.catalog_country)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, instances.map { it.label })
        findViewById<MaterialButton>(R.id.catalog_search).setOnClickListener { search() }
        findViewById<EditText>(R.id.catalog_filter).setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false
        }
    }

    private fun search() {
        val query = findViewById<EditText>(R.id.catalog_filter).text.toString().trim()
        if (query.length < 2) {
            findViewById<EditText>(R.id.catalog_filter).error = getString(R.string.peertube_query_short)
            return
        }
        searchJob?.cancel()
        val instance = instances[findViewById<Spinner>(R.id.catalog_country).selectedItemPosition]
        searchJob = lifecycleScope.launch {
            updateStatus(getString(R.string.peertube_searching, instance.label))
            try {
                val found = withContext(Dispatchers.IO) {
                    val endpoint = instance.base + "/api/v1/search/videos?search=" + Uri.encode(query) + "&count=30&nsfw=false&isLive=false"
                    val response = getJson(endpoint)
                    val data = response.optJSONArray("data") ?: org.json.JSONArray()
                    (0 until data.length()).mapNotNull { index ->
                        val item = data.optJSONObject(index) ?: return@mapNotNull null
                        if (item.optBoolean("nsfw", false)) return@mapNotNull null
                        val url = item.optString("url")
                        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return@mapNotNull null
                        val host = "https://${uri.host ?: return@mapNotNull null}"
                        val uuid = item.optString("uuid")
                        if (uuid.isBlank()) return@mapNotNull null
                        val channel = item.optJSONObject("channel")?.optString("displayName").orEmpty()
                        Video(item.optString("name"), host, uuid, channel, item.optString("truncatedDescription"))
                    }
                }
                videos = found
                updateStatus(
                    if (found.isEmpty()) getString(R.string.peertube_no_results)
                    else getString(R.string.peertube_results, found.size, instance.label)
                )
                showRows(R.id.catalog_results, found.map { it.title to it.channel }) { index -> playVideo(found[index]) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                updateStatus(getString(R.string.catalog_error, e.localizedMessage ?: e.javaClass.simpleName))
            }
        }
    }

    private fun playVideo(video: Video) {
        lifecycleScope.launch {
            updateStatus(getString(R.string.peertube_loading_video, video.title))
            try {
                val url = withContext(Dispatchers.IO) {
                    val json = getJson("${video.host}/api/v1/videos/${video.uuid}")
                    val playlists = json.optJSONArray("streamingPlaylists")
                    val playlist = playlists?.optJSONObject(0)?.optString("playlistUrl").orEmpty()
                    if (playlist.isNotBlank()) playlist else {
                        val files = json.optJSONArray("files") ?: error("No public playable files")
                        val candidates = (0 until files.length()).mapNotNull { files.optJSONObject(it)?.optString("fileUrl")?.takeIf(String::isNotBlank) }
                        candidates.firstOrNull() ?: error("No public playable files")
                    }
                }
                updateStatus(getString(R.string.peertube_playing, video.title, video.host))
                val mime = if (url.contains(".m3u8", true)) androidx.media3.common.MimeTypes.APPLICATION_M3U8 else null
                playUrl(url, video.title, mime)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                updateStatus(getString(R.string.catalog_error, e.localizedMessage ?: e.javaClass.simpleName))
            }
        }
    }

    private fun getJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 25000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "LaClaveTube/1.0")
        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) error("HTTP $status: ${body.take(160)}")
            return JSONObject(body)
        } finally { connection.disconnect() }
    }
}
