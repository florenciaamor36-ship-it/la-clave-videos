package com.github.libretube.ui.models

import org.json.JSONArray
import org.json.JSONObject

data class CustomExploreSearchShortcut(val title: String, val query: String) {
    companion object {
        private const val MAX_SHORTCUTS = 30
        fun decode(serialized: String): List<CustomExploreSearchShortcut> = runCatching {
            val array = JSONArray(serialized)
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val title = item.optString("title").trim().take(48)
                val query = item.optString("query").trim().take(180)
                if (title.isBlank() || query.isBlank()) null
                else CustomExploreSearchShortcut(title, query)
            }.distinctBy { it.title.lowercase() to it.query.lowercase() }.take(MAX_SHORTCUTS)
        }.getOrDefault(emptyList())

        fun encode(items: List<CustomExploreSearchShortcut>): String = JSONArray().apply {
            items.map { CustomExploreSearchShortcut(it.title.trim().take(48), it.query.trim().take(180)) }
                .filter { it.title.isNotBlank() && it.query.isNotBlank() }
                .distinctBy { it.title.lowercase() to it.query.lowercase() }
                .take(MAX_SHORTCUTS)
                .forEach { put(JSONObject().put("title", it.title).put("query", it.query)) }
        }.toString()
    }
}
