package com.github.libretube.ui.models

import org.json.JSONArray
import org.json.JSONObject

/** A user-defined shortcut that opens a normal search-results screen. */
data class CustomExploreSearchShortcut(val title: String, val query: String) {
    companion object {
        private const val MAX_SHORTCUTS = 30
        private const val MAX_TITLE_LENGTH = 48
        private const val MAX_QUERY_LENGTH = 180

        fun decode(serialized: String): List<CustomExploreSearchShortcut> = runCatching {
            val array = JSONArray(serialized)
            (0 until array.length()).mapNotNull { index ->
                val row = array.optJSONObject(index) ?: return@mapNotNull null
                val title = row.optString("title").trim().take(MAX_TITLE_LENGTH)
                val query = row.optString("query").trim().take(MAX_QUERY_LENGTH)
                if (title.isBlank() || query.isBlank()) null
                else CustomExploreSearchShortcut(title, query)
            }.distinctBy { it.title.lowercase() to it.query.lowercase() }
                .take(MAX_SHORTCUTS)
        }.getOrDefault(emptyList())

        fun encode(shortcuts: List<CustomExploreSearchShortcut>): String =
            JSONArray().apply {
                shortcuts.asSequence()
                    .map { CustomExploreSearchShortcut(
                        it.title.trim().take(MAX_TITLE_LENGTH),
                        it.query.trim().take(MAX_QUERY_LENGTH)
                    ) }
                    .filter { it.title.isNotBlank() && it.query.isNotBlank() }
                    .distinctBy { it.title.lowercase() to it.query.lowercase() }
                    .take(MAX_SHORTCUTS)
                    .forEach { shortcut ->
                        put(JSONObject().apply {
                            put("title", shortcut.title)
                            put("query", shortcut.query)
                        })
                    }
            }.toString()
    }
}
