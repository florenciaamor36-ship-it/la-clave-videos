package com.github.libretube.ui.activities

import android.os.Bundle
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.MediaRouteButtonFactory
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.mediarouter.app.MediaRouteButton
import com.github.libretube.R
import com.google.android.material.appbar.MaterialToolbar

@OptIn(androidx.media3.common.util.UnstableApi::class)
abstract class MediaCatalogActivity : AppCompatActivity() {
    private var localPlayer: ExoPlayer? = null
    private var castPlayer: CastPlayer? = null
    private var playerView: PlayerView? = null

    protected fun setupCatalog(layout: Int, title: Int) {
        setContentView(layout)
        findViewById<MaterialToolbar>(R.id.catalog_toolbar).apply {
            this.title = getString(title)
            setNavigationIcon(R.drawable.ic_catalog_back)
            setNavigationOnClickListener { finish() }
        }
        playerView = findViewById<PlayerView>(R.id.catalog_player)
        localPlayer = ExoPlayer.Builder(this).build()
        castPlayer = runCatching {
            CastPlayer.Builder(this).setLocalPlayer(localPlayer!!).build()
        }.getOrNull()
        val activePlayer = castPlayer ?: localPlayer!!
        activePlayer.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                updateStatus(getString(R.string.catalog_error, error.localizedMessage ?: getString(R.string.playback_error)))
            }
        })
        playerView?.player = activePlayer
        findViewById<MediaRouteButton>(R.id.catalog_cast_button)?.let { button ->
            if (castPlayer == null) {
                button.isEnabled = false
                button.alpha = 0.45f
            } else {
                runCatching { MediaRouteButtonFactory.setUpMediaRouteButton(this, button) }
                    .onFailure {
                        button.isEnabled = false
                        button.alpha = 0.45f
                    }
            }
        }
    }

    protected fun updateStatus(text: CharSequence) {
        findViewById<TextView>(R.id.catalog_status)?.text = text
    }

    protected fun showRows(containerId: Int, items: List<Pair<String, String>>, onClick: (Int) -> Unit) {
        val container = findViewById<android.widget.LinearLayout>(containerId) ?: return
        container.removeAllViews()
        items.forEachIndexed { index, (title, subtitle) ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                isClickable = true
                isFocusable = true
                setBackgroundResource(android.R.drawable.list_selector_background)
                val inset = (12 * resources.displayMetrics.density).toInt()
                setPadding(inset, inset, inset, inset)
                layoutParams = ViewGroup.LayoutParams(-1, -2)
            }
            row.addView(TextView(this).apply {
                text = title
                textSize = 16f
                setTextColor(com.google.android.material.color.MaterialColors.getColor(row, com.google.android.material.R.attr.colorOnSurface))
                maxLines = 2
            })
            if (subtitle.isNotBlank()) row.addView(TextView(this).apply {
                text = subtitle
                textSize = 12f
                setTextColor(com.google.android.material.color.MaterialColors.getColor(row, com.google.android.material.R.attr.colorOnSurfaceVariant))
                maxLines = 2
            })
            row.setOnClickListener { onClick(index) }
            container.addView(row)
        }
    }

    protected fun playUrl(url: String, title: String, mimeType: String? = null) {
        val player = castPlayer ?: localPlayer ?: return
        val item = MediaItem.Builder()
            .setUri(url)
            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(title).build())
            .apply { if (!mimeType.isNullOrBlank()) setMimeType(mimeType) }
            .build()
        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
    }

    override fun onStart() {
        super.onStart()
        playerView?.onResume()
    }

    override fun onStop() {
        playerView?.onPause()
        super.onStop()
    }

    override fun onDestroy() {
        playerView?.player = null
        localPlayer?.release()
        localPlayer = null
        castPlayer = null
        super.onDestroy()
    }
}
