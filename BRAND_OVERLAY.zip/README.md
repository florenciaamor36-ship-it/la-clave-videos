# Clave Video — La Clave Argentina

Aplicación Android basada en LibreTube (GPL-3.0-or-later), personalizada para La Clave Argentina. No es un producto oficial de YouTube ni de los autores de LibreTube.

## Build de prueba

La acción «Build Clave Video APK» compila una APK debug. Su firma no es una clave de publicación estable; esta APK de prueba puede no actualizar una instalación firmada con otra clave.

## Licencia y código fuente

Se conservan los avisos de copyright, créditos y archivos de licencia del proyecto LibreTube. La modificación y distribución de esta versión derivada se ofrece bajo GNU GPL v3 o posterior. Al redistribuir la APK, conservá esos avisos y ofrecé el código fuente correspondiente, incluidos los cambios y scripts usados para compilar.

Los recursos promocionales de La Clave Argentina fueron aportados para esta marca y son independientes del código upstream.

## Cambios de marca

- Nombre: Clave Video; paquete independiente: `ar.com.laclave.videos`.
- Español de Argentina por defecto en la primera instalación; tema dorado y carbón.
- Promociones de La Clave Argentina y botón de WhatsApp con destino a su número de contacto.
