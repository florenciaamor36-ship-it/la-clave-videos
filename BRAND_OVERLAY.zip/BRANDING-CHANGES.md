# Cambios de marca — Clave Video

Basado en LibreTube, GPL-3.0-or-later, con avisos upstream conservados. Cambios: paquete `ar.com.laclave.videos`; nombre Clave Video; idioma es-AR inicial; paleta carbón y dorado; icono y splash; once anuncios rotativos con temporizador de 5 segundos al entrar a Inicio; banner WhatsApp de La Clave Argentina que abre conversación con el número enlazado.

La build de CI genera APK debug para prueba. La firma debug no es estable para instalaciones futuras.
